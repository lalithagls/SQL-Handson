select rental_id,car_id,customer_id,km_driven from rentals 
where MONTH(return_date)=8 and YEAR(return_date)=2019;