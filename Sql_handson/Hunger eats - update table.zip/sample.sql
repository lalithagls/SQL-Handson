update customers
set phone_no='9876543210'
where customer_id='CUST1004';