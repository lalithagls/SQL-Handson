SELECT customer_id,customer_name,address,phone_no FROM customers 
where email_id is not null order by customer_id;