INSERT INTO Department 
(department_id,department_name,department_block_number) 
values
(1,'CSE',3),
(2,'IT',3),
(3,'SE',3);