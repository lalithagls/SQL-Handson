select h.hotel_id,h.hotel_name,count(o.hotel_id) as NO_OF_ORDERS from hotel_details h join orders o
on o.hotel_id=h.hotel_id
group by o.hotel_id 
having NO_OF_ORDERS>5;