/*select customer_id,customer_name,COALESCE(address, email_id, 'NA') as CONTACT_DETAILS 
from customers order by customer_id;*/

select customer_id,customer_name,
case
 when address is null and email_id is null then 'NA'  
 when address is null then email_id
 else address
end as CONTACT_DETAILS 
from customers order by customer_id;