alter table customers 
modify customer_id int;