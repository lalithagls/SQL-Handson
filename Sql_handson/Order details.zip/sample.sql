select o.order_id, c.customer_name, h.hotel_name,o.order_amount from orders o
inner join hotel_details h on o.hotel_id=h.hotel_id
inner join customers c on o.customer_id=c.customer_id
order by o.order_id ;